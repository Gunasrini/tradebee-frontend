import axios from 'axios'
import React from 'react'

export default function TestApi() {
    // const formData = {
    //     username: "praba123@gmail.com",
    //     password: "praba#123"
    // }
    // axios.post("https://api.binary-coders.in/user/login", formData, {
    //     mode: 'no-cors',
    //     headers: {
    //         "Content-Type": "application/json",
    //     },
    // })
    //     .then(response => console.log(response));

    const testFunction = async (e) => {
        try {
            const url = 'https://rapidapi.com/learn/api/rest';
            const data = { firstName: 'John', secondName: 'Doe', email: 'jd@gmail.com' };
            // Specifying headers in the config object
            const config = { 'content-type': 'application/json', mode: 'no-cors', };
            const response = await axios.post(url, data, config);
            console.log(response.data);
        } catch (error) {
            console.error(error);
        }
    }

    // testFunction();

    fetch('https://api.binary-coders.in/user/login', {
        method: 'POST',
        body: JSON.stringify({
            username: 'praba123@gmail.com',
            passsword: 'praba#123',
        }),
        headers: {
            'Content-type': 'application/json; charset=UTF-8',
        },
    })
        .then((response) => response.json())
        .then((json) => console.log(json));

    return (
        <div>TestApi</div>
    )
}
